#ifndef _COMPROMISSO_
#define _COMPROMISSO_

#include <iostream>
#include <cstring>
using namespace std;

struct Compromisso{ // Um compromisso para compor o dia
    int hora;
    int minuto;
    string descricao;
};

#endif
